import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from mpl_toolkits.mplot3d import Axes3D
from PIL import Image
import cv2

class Histogram3DGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("3D Histogram Generator")
        self.root.geometry("1400x900")
        
        # Variables to store image paths and data
        self.original_path = tk.StringVar()
        self.encrypted_path = tk.StringVar()
        self.decrypted_path = tk.StringVar()
        
        self.original_image = None
        self.encrypted_image = None
        self.decrypted_image = None
        
        self.setup_ui()
        
    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="3D Histogram Generator for Images", 
                               font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        # File selection section
        file_frame = ttk.LabelFrame(main_frame, text="Image Selection", padding="10")
        file_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        file_frame.columnconfigure(1, weight=1)
        
        # Original image
        ttk.Label(file_frame, text="Original Image:").grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Entry(file_frame, textvariable=self.original_path, width=50).grid(row=0, column=1, sticky=(tk.W, tk.E), padx=5)
        ttk.Button(file_frame, text="Browse", command=lambda: self.browse_file(self.original_path)).grid(row=0, column=2, padx=5)
        
        # Encrypted image
        ttk.Label(file_frame, text="Encrypted Image:").grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Entry(file_frame, textvariable=self.encrypted_path, width=50).grid(row=1, column=1, sticky=(tk.W, tk.E), padx=5)
        ttk.Button(file_frame, text="Browse", command=lambda: self.browse_file(self.encrypted_path)).grid(row=1, column=2, padx=5)
        
        # Decrypted image
        ttk.Label(file_frame, text="Decrypted Image:").grid(row=2, column=0, sticky=tk.W, pady=5)
        ttk.Entry(file_frame, textvariable=self.decrypted_path, width=50).grid(row=2, column=1, sticky=(tk.W, tk.E), padx=5)
        ttk.Button(file_frame, text="Browse", command=lambda: self.browse_file(self.decrypted_path)).grid(row=2, column=2, padx=5)
        
        # Control options
        options_frame = ttk.LabelFrame(main_frame, text="Histogram Options", padding="10")
        options_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Histogram type selection
        ttk.Label(options_frame, text="Histogram Type:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.hist_type = tk.StringVar(value="intensity")
        hist_combo = ttk.Combobox(options_frame, textvariable=self.hist_type, 
                                 values=["intensity", "rgb", "hsv", "surface"], state="readonly")
        hist_combo.grid(row=0, column=1, sticky=tk.W, padx=5)
        
        # Bins selection
        ttk.Label(options_frame, text="Bins:").grid(row=0, column=2, sticky=tk.W, pady=5, padx=(20, 0))
        self.bins = tk.StringVar(value="32")
        bins_combo = ttk.Combobox(options_frame, textvariable=self.bins, 
                                 values=["16", "32", "64", "128", "256"], state="readonly", width=10)
        bins_combo.grid(row=0, column=3, sticky=tk.W, padx=5)
        
        # Control buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=3, column=0, columnspan=3, pady=10)
        
        ttk.Button(button_frame, text="Load Images", command=self.load_images).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Generate 3D Histograms", command=self.generate_histograms).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Compare Histograms", command=self.compare_histograms).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Save Plots", command=self.save_plots).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Clear All", command=self.clear_all).pack(side=tk.LEFT, padx=5)
        
        # Results notebook
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.grid(row=4, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=10)
        main_frame.rowconfigure(4, weight=1)
        
        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set("Ready - Select images and generate 3D histograms")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.grid(row=5, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(10, 0))
        
    def browse_file(self, path_var):
        """Open file dialog to select an image"""
        filename = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[
                ("Image files", "*.jpg *.jpeg *.png *.bmp *.tiff *.gif"),
                ("All files", "*.*")
            ]
        )
        if filename:
            path_var.set(filename)
            
    def load_images(self):
        """Load all selected images"""
        try:
            self.status_var.set("Loading images...")
            self.root.update()
            
            # Load original image
            if self.original_path.get():
                self.original_image = cv2.imread(self.original_path.get())
                self.original_image = cv2.cvtColor(self.original_image, cv2.COLOR_BGR2RGB)
                
            # Load encrypted image
            if self.encrypted_path.get():
                self.encrypted_image = cv2.imread(self.encrypted_path.get())
                self.encrypted_image = cv2.cvtColor(self.encrypted_image, cv2.COLOR_BGR2RGB)
                
            # Load decrypted image
            if self.decrypted_path.get():
                self.decrypted_image = cv2.imread(self.decrypted_path.get())
                self.decrypted_image = cv2.cvtColor(self.decrypted_image, cv2.COLOR_BGR2RGB)
                
            self.status_var.set("Images loaded successfully")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error loading images: {str(e)}")
            self.status_var.set("Error loading images")
            
    def generate_histograms(self):
        """Generate 3D histograms for all loaded images"""
        try:
            self.status_var.set("Generating 3D histograms...")
            self.root.update()
            
            # Clear previous tabs
            for tab in self.notebook.tabs():
                self.notebook.forget(tab)
                
            images = []
            labels = []
            
            if self.original_image is not None:
                images.append(self.original_image)
                labels.append("Original")
                
            if self.encrypted_image is not None:
                images.append(self.encrypted_image)
                labels.append("Encrypted")
                
            if self.decrypted_image is not None:
                images.append(self.decrypted_image)
                labels.append("Decrypted")
                
            if not images:
                messagebox.showwarning("Warning", "Please load at least one image first")
                return
                
            # Generate histograms based on selected type
            hist_type = self.hist_type.get()
            bins = int(self.bins.get())
            
            for i, (image, label) in enumerate(zip(images, labels)):
                frame = ttk.Frame(self.notebook)
                self.notebook.add(frame, text=f"{label} - 3D Histogram")
                
                if hist_type == "intensity":
                    self.create_intensity_histogram(frame, image, label, bins)
                elif hist_type == "rgb":
                    self.create_rgb_histogram(frame, image, label, bins)
                elif hist_type == "hsv":
                    self.create_hsv_histogram(frame, image, label, bins)
                elif hist_type == "surface":
                    self.create_surface_histogram(frame, image, label, bins)
                    
            self.status_var.set("3D histograms generated successfully")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error generating histograms: {str(e)}")
            self.status_var.set("Error generating histograms")
            
    def create_intensity_histogram(self, parent, image, label, bins):
        """Create 3D intensity histogram"""
        fig = plt.figure(figsize=(12, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        
        # Create histogram
        hist, bin_edges = np.histogram(gray.flatten(), bins=bins, range=(0, 256))
        
        # Create 3D bar plot
        x = bin_edges[:-1]
        y = np.zeros_like(x)
        z = np.zeros_like(x)
        dx = np.ones_like(x) * (256 / bins)
        dy = np.ones_like(x) * 0.5
        dz = hist
        
        ax.bar3d(x, y, z, dx, dy, dz, color='skyblue', alpha=0.7)
        
        ax.set_xlabel('Intensity Value')
        ax.set_ylabel('Y')
        ax.set_zlabel('Frequency')
        ax.set_title(f'{label} - Intensity Histogram 3D')
        
        # Add to GUI
        canvas = FigureCanvasTkAgg(fig, parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
    def create_rgb_histogram(self, parent, image, label, bins):
        """Create 3D RGB histogram"""
        fig = plt.figure(figsize=(12, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        # Calculate histograms for each channel
        colors = ['red', 'green', 'blue']
        channel_names = ['Red', 'Green', 'Blue']
        
        for i, (color, channel_name) in enumerate(zip(colors, channel_names)):
            hist, bin_edges = np.histogram(image[:,:,i].flatten(), bins=bins, range=(0, 256))
            
            x = bin_edges[:-1]
            y = np.full_like(x, i)
            z = np.zeros_like(x)
            dx = np.ones_like(x) * (256 / bins)
            dy = np.ones_like(x) * 0.8
            dz = hist
            
            ax.bar3d(x, y, z, dx, dy, dz, color=color, alpha=0.7, label=channel_name)
        
        ax.set_xlabel('Intensity Value')
        ax.set_ylabel('Channel')
        ax.set_zlabel('Frequency')
        ax.set_title(f'{label} - RGB Histogram 3D')
        ax.legend()
        
        # Add to GUI
        canvas = FigureCanvasTkAgg(fig, parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
    def create_hsv_histogram(self, parent, image, label, bins):
        """Create 3D HSV histogram"""
        fig = plt.figure(figsize=(12, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        # Convert to HSV
        hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
        
        # Calculate histograms for each channel
        colors = ['orange', 'purple', 'cyan']
        channel_names = ['Hue', 'Saturation', 'Value']
        ranges = [(0, 180), (0, 256), (0, 256)]
        
        for i, (color, channel_name, (min_val, max_val)) in enumerate(zip(colors, channel_names, ranges)):
            hist, bin_edges = np.histogram(hsv[:,:,i].flatten(), bins=bins, range=(min_val, max_val))
            
            x = bin_edges[:-1]
            y = np.full_like(x, i)
            z = np.zeros_like(x)
            dx = np.ones_like(x) * ((max_val - min_val) / bins)
            dy = np.ones_like(x) * 0.8
            dz = hist
            
            ax.bar3d(x, y, z, dx, dy, dz, color=color, alpha=0.7, label=channel_name)
        
        ax.set_xlabel('Value')
        ax.set_ylabel('Channel')
        ax.set_zlabel('Frequency')
        ax.set_title(f'{label} - HSV Histogram 3D')
        ax.legend()
        
        # Add to GUI
        canvas = FigureCanvasTkAgg(fig, parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
    def create_surface_histogram(self, parent, image, label, bins):
        """Create 3D surface histogram using 2D histogram"""
        fig = plt.figure(figsize=(12, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        
        # Create 2D histogram (intensity vs position)
        height, width = gray.shape
        y_coords = np.repeat(np.arange(height), width)
        x_coords = np.tile(np.arange(width), height)
        intensities = gray.flatten()
        
        # Subsample for performance
        subsample = min(10000, len(intensities))
        indices = np.random.choice(len(intensities), subsample, replace=False)
        
        x_sub = x_coords[indices]
        y_sub = y_coords[indices]
        z_sub = intensities[indices]
        
        # Create 3D scatter plot
        ax.scatter(x_sub, y_sub, z_sub, c=z_sub, cmap='viridis', alpha=0.6, s=1)
        
        ax.set_xlabel('X Position')
        ax.set_ylabel('Y Position')
        ax.set_zlabel('Intensity')
        ax.set_title(f'{label} - Surface Intensity Distribution')
        
        # Add to GUI
        canvas = FigureCanvasTkAgg(fig, parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
    def compare_histograms(self):
        """Compare histograms of all images in one plot"""
        try:
            if not any([self.original_image is not None, self.encrypted_image is not None, self.decrypted_image is not None]):
                messagebox.showwarning("Warning", "Please load at least one image first")
                return
                
            self.status_var.set("Generating comparison plot...")
            self.root.update()
            
            # Create comparison tab
            compare_frame = ttk.Frame(self.notebook)
            self.notebook.add(compare_frame, text="Comparison")
            
            fig = plt.figure(figsize=(15, 10))
            
            images = []
            labels = []
            colors = ['blue', 'red', 'green']
            
            if self.original_image is not None:
                images.append(self.original_image)
                labels.append("Original")
                
            if self.encrypted_image is not None:
                images.append(self.encrypted_image)
                labels.append("Encrypted")
                
            if self.decrypted_image is not None:
                images.append(self.decrypted_image)
                labels.append("Decrypted")
                
            bins = int(self.bins.get())
            
            # Create subplots for different views
            ax1 = fig.add_subplot(221, projection='3d')
            ax2 = fig.add_subplot(222)
            ax3 = fig.add_subplot(223)
            ax4 = fig.add_subplot(224)
            
            # 3D comparison
            for i, (image, label, color) in enumerate(zip(images, labels, colors)):
                gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
                hist, bin_edges = np.histogram(gray.flatten(), bins=bins, range=(0, 256))
                
                x = bin_edges[:-1]
                y = np.full_like(x, i)
                z = np.zeros_like(x)
                dx = np.ones_like(x) * (256 / bins)
                dy = np.ones_like(x) * 0.8
                dz = hist
                
                ax1.bar3d(x, y, z, dx, dy, dz, color=color, alpha=0.7, label=label)
                
                # 2D histogram comparison
                ax2.plot(x, hist, color=color, label=label, linewidth=2)
                
            ax1.set_title('3D Histogram Comparison')
            ax1.set_xlabel('Intensity')
            ax1.set_ylabel('Image')
            ax1.set_zlabel('Frequency')
            ax1.legend()
            
            ax2.set_title('2D Histogram Comparison')
            ax2.set_xlabel('Intensity')
            ax2.set_ylabel('Frequency')
            ax2.legend()
            ax2.grid(True, alpha=0.3)
            
            # Statistical comparison
            stats_text = "Statistical Comparison:\n\n"
            for i, (image, label) in enumerate(zip(images, labels)):
                gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
                mean_val = np.mean(gray)
                std_val = np.std(gray)
                entropy = -np.sum(np.histogram(gray, bins=256, range=(0, 256))[0] * np.log2(np.histogram(gray, bins=256, range=(0, 256))[0] + 1e-10))
                
                stats_text += f"{label}:\n"
                stats_text += f"  Mean: {mean_val:.2f}\n"
                stats_text += f"  Std: {std_val:.2f}\n"
                stats_text += f"  Entropy: {entropy:.2f}\n\n"
                
            ax3.text(0.1, 0.9, stats_text, transform=ax3.transAxes, fontsize=10, 
                    verticalalignment='top', fontfamily='monospace')
            ax3.set_title('Statistical Analysis')
            ax3.axis('off')
            
            # Difference analysis
            if len(images) >= 2:
                diff_text = "Difference Analysis:\n\n"
                for i in range(len(images)):
                    for j in range(i+1, len(images)):
                        gray1 = cv2.cvtColor(images[i], cv2.COLOR_RGB2GRAY)
                        gray2 = cv2.cvtColor(images[j], cv2.COLOR_RGB2GRAY)
                        
                        mse = np.mean((gray1 - gray2) ** 2)
                        psnr = 20 * np.log10(255 / np.sqrt(mse)) if mse > 0 else float('inf')
                        
                        diff_text += f"{labels[i]} vs {labels[j]}:\n"
                        diff_text += f"  MSE: {mse:.2f}\n"
                        diff_text += f"  PSNR: {psnr:.2f} dB\n\n"
                        
                ax4.text(0.1, 0.9, diff_text, transform=ax4.transAxes, fontsize=10,
                        verticalalignment='top', fontfamily='monospace')
                ax4.set_title('Difference Analysis')
                ax4.axis('off')
            
            plt.tight_layout()
            
            # Add to GUI
            canvas = FigureCanvasTkAgg(fig, compare_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
            self.status_var.set("Comparison generated successfully")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error generating comparison: {str(e)}")
            self.status_var.set("Error generating comparison")
            
    def save_plots(self):
        """Save all generated plots"""
        try:
            save_dir = filedialog.askdirectory(title="Select directory to save plots")
            if not save_dir:
                return
                
            self.status_var.set("Saving plots...")
            self.root.update()
            
            # Save each tab as a separate image
            for i, tab_id in enumerate(self.notebook.tabs()):
                tab_text = self.notebook.tab(tab_id, "text")
                # Here you would implement saving logic for each canvas
                
            self.status_var.set("Plots saved successfully")
            messagebox.showinfo("Success", f"Plots saved to {save_dir}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error saving plots: {str(e)}")
            self.status_var.set("Error saving plots")
            
    def clear_all(self):
        """Clear all loaded images and generated plots"""
        self.original_path.set("")
        self.encrypted_path.set("")
        self.decrypted_path.set("")
        
        self.original_image = None
        self.encrypted_image = None
        self.decrypted_image = None
        
        # Clear all tabs
        for tab in self.notebook.tabs():
            self.notebook.forget(tab)
            
        self.status_var.set("All data cleared")

if __name__ == "__main__":
    root = tk.Tk()
    app = Histogram3DGenerator(root)
    root.mainloop()