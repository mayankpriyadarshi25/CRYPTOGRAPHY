import tkinter as tk
from tkinter import filedialog, messagebox
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from PIL import Image
import cv2

class ImageHistogramAnalyzer:
    def __init__(self, root):
        self.root = root
        self.root.title("Image Histogram Analyzer")
        self.root.geometry("1000x700")
        
        # Variables
        self.original_image = None
        self.encrypted_image = None
        self.decrypted_image = None
        
        # File paths for display
        self.original_path = "No file selected"
        self.encrypted_path = "No file selected"
        self.decrypted_path = "No file selected"
        
        # Create GUI elements
        self.create_widgets()
        
    def create_widgets(self):
        # Main frame
        main_frame = tk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # File selection frame
        file_frame = tk.Frame(main_frame)
        file_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Original image selection
        orig_frame = tk.Frame(file_frame)
        orig_frame.pack(fill=tk.X, pady=2)
        tk.Label(orig_frame, text="Original Image:", width=15, anchor='w').pack(side=tk.LEFT)
        self.orig_label = tk.Label(orig_frame, text=self.original_path, bg='white', relief='sunken', anchor='w')
        self.orig_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 5))
        tk.Button(orig_frame, text="Browse", command=self.select_original, bg="lightblue").pack(side=tk.RIGHT)
        
        # Encrypted image selection
        enc_frame = tk.Frame(file_frame)
        enc_frame.pack(fill=tk.X, pady=2)
        tk.Label(enc_frame, text="Encrypted Image:", width=15, anchor='w').pack(side=tk.LEFT)
        self.enc_label = tk.Label(enc_frame, text=self.encrypted_path, bg='white', relief='sunken', anchor='w')
        self.enc_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 5))
        tk.Button(enc_frame, text="Browse", command=self.select_encrypted, bg="lightcoral").pack(side=tk.RIGHT)
        
        # Decrypted image selection
        dec_frame = tk.Frame(file_frame)
        dec_frame.pack(fill=tk.X, pady=2)
        tk.Label(dec_frame, text="Decrypted Image:", width=15, anchor='w').pack(side=tk.LEFT)
        self.dec_label = tk.Label(dec_frame, text=self.decrypted_path, bg='white', relief='sunken', anchor='w')
        self.dec_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 5))
        tk.Button(dec_frame, text="Browse", command=self.select_decrypted, bg="lightgreen").pack(side=tk.RIGHT)
        
        # Analyze button
        analyze_btn = tk.Button(file_frame, text="Analyze Histograms", 
                               command=self.analyze_histograms, bg="gold", font=('Arial', 10, 'bold'))
        analyze_btn.pack(pady=10)
        
        # Results frame
        self.results_frame = tk.Frame(main_frame)
        self.results_frame.pack(fill=tk.BOTH, expand=True)
        
        # Canvas for matplotlib
        self.canvas_frame = tk.Frame(self.results_frame)
        self.canvas_frame.pack(fill=tk.BOTH, expand=True)
        
    def select_original(self):
        file_path = filedialog.askopenfilename(
            title="Select Original Image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.tiff")]
        )
        
        if file_path:
            try:
                self.original_image = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
                if self.original_image is None:
                    messagebox.showerror("Error", "Could not load original image")
                    return
                self.original_path = file_path.split('/')[-1]
                self.orig_label.config(text=self.original_path)
            except Exception as e:
                messagebox.showerror("Error", f"Error loading original image: {str(e)}")
    
    def select_encrypted(self):
        file_path = filedialog.askopenfilename(
            title="Select Encrypted Image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.tiff")]
        )
        
        if file_path:
            try:
                self.encrypted_image = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
                if self.encrypted_image is None:
                    messagebox.showerror("Error", "Could not load encrypted image")
                    return
                self.encrypted_path = file_path.split('/')[-1]
                self.enc_label.config(text=self.encrypted_path)
            except Exception as e:
                messagebox.showerror("Error", f"Error loading encrypted image: {str(e)}")
    
    def select_decrypted(self):
        file_path = filedialog.askopenfilename(
            title="Select Decrypted Image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.tiff")]
        )
        
        if file_path:
            try:
                self.decrypted_image = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
                if self.decrypted_image is None:
                    messagebox.showerror("Error", "Could not load decrypted image")
                    return
                self.decrypted_path = file_path.split('/')[-1]
                self.dec_label.config(text=self.decrypted_path)
            except Exception as e:
                messagebox.showerror("Error", f"Error loading decrypted image: {str(e)}")
    
    def analyze_histograms(self):
        # Check if all images are loaded
        if self.original_image is None:
            messagebox.showerror("Error", "Please select an original image")
            return
        if self.encrypted_image is None:
            messagebox.showerror("Error", "Please select an encrypted image")
            return
        if self.decrypted_image is None:
            messagebox.showerror("Error", "Please select a decrypted image")
            return
        
        # Clear previous plots
        for widget in self.canvas_frame.winfo_children():
            widget.destroy()
        
        # Create matplotlib figure
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        fig.suptitle('Image Histogram Analysis', fontsize=16, fontweight='bold')
        
        # Plot images
        axes[0, 0].imshow(self.original_image, cmap='gray')
        axes[0, 0].set_title('Original Image', fontweight='bold')
        axes[0, 0].axis('off')
        
        axes[0, 1].imshow(self.encrypted_image, cmap='gray')
        axes[0, 1].set_title('Encrypted Image', fontweight='bold')
        axes[0, 1].axis('off')
        
        axes[0, 2].imshow(self.decrypted_image, cmap='gray')
        axes[0, 2].set_title('Decrypted Image', fontweight='bold')
        axes[0, 2].axis('off')
        
        # Plot histograms
        axes[1, 0].hist(self.original_image.flatten(), bins=256, color='blue', alpha=0.7, edgecolor='black')
        axes[1, 0].set_title('Original Histogram', fontweight='bold')
        axes[1, 0].set_xlabel('Pixel Value')
        axes[1, 0].set_ylabel('Frequency')
        axes[1, 0].grid(True, alpha=0.3)
        
        axes[1, 1].hist(self.encrypted_image.flatten(), bins=256, color='red', alpha=0.7, edgecolor='black')
        axes[1, 1].set_title('Encrypted Histogram', fontweight='bold')
        axes[1, 1].set_xlabel('Pixel Value')
        axes[1, 1].set_ylabel('Frequency')
        axes[1, 1].grid(True, alpha=0.3)
        
        axes[1, 2].hist(self.decrypted_image.flatten(), bins=256, color='green', alpha=0.7, edgecolor='black')
        axes[1, 2].set_title('Decrypted Histogram', fontweight='bold')
        axes[1, 2].set_xlabel('Pixel Value')
        axes[1, 2].set_ylabel('Frequency')
        axes[1, 2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        # Embed in tkinter
        canvas = FigureCanvasTkAgg(fig, self.canvas_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Analyze and display results
        self.analyze_and_display_results()
    
    def analyze_and_display_results(self):
        """Analyze histograms and display comparison results"""
        # Calculate histograms
        orig_hist = cv2.calcHist([self.original_image], [0], None, [256], [0, 256])
        enc_hist = cv2.calcHist([self.encrypted_image], [0], None, [256], [0, 256])
        dec_hist = cv2.calcHist([self.decrypted_image], [0], None, [256], [0, 256])
        
        # Calculate correlations
        orig_dec_corr = cv2.compareHist(orig_hist, dec_hist, cv2.HISTCMP_CORREL)
        orig_enc_corr = cv2.compareHist(orig_hist, enc_hist, cv2.HISTCMP_CORREL)
        enc_dec_corr = cv2.compareHist(enc_hist, dec_hist, cv2.HISTCMP_CORREL)
        
        # Calculate other metrics
        orig_mean = np.mean(self.original_image)
        enc_mean = np.mean(self.encrypted_image)
        dec_mean = np.mean(self.decrypted_image)
        
        orig_std = np.std(self.original_image)
        enc_std = np.std(self.encrypted_image)
        dec_std = np.std(self.decrypted_image)
        
        # Print results
        print("\n" + "="*50)
        print("HISTOGRAM ANALYSIS RESULTS")
        print("="*50)
        print(f"Original vs Decrypted correlation: {orig_dec_corr:.4f}")
        print(f"Original vs Encrypted correlation: {orig_enc_corr:.4f}")
        print(f"Encrypted vs Decrypted correlation: {enc_dec_corr:.4f}")
        print()
        print("Image Statistics:")
        print(f"Original - Mean: {orig_mean:.2f}, Std: {orig_std:.2f}")
        print(f"Encrypted - Mean: {enc_mean:.2f}, Std: {enc_std:.2f}")
        print(f"Decrypted - Mean: {dec_mean:.2f}, Std: {dec_std:.2f}")
        print()
        
        # Analysis results
        if orig_dec_corr > 0.99:
            print("✓ EXCELLENT: Decryption successful - histograms match perfectly!")
        elif orig_dec_corr > 0.95:
            print("✓ GOOD: Decryption mostly successful - minor differences detected")
        elif orig_dec_corr > 0.80:
            print("⚠ FAIR: Decryption has some issues - noticeable differences")
        else:
            print("✗ POOR: Decryption failed - significant differences detected")
        
        if orig_enc_corr < 0.5:
            print("✓ GOOD: Encryption appears effective - low correlation with original")
        else:
            print("⚠ WARNING: Encryption may be weak - high correlation with original")
        
        print("="*50)
        
        # Show message box with summary
        summary = f"""Analysis Complete!
        
Original ↔ Decrypted: {orig_dec_corr:.4f}
Original ↔ Encrypted: {orig_enc_corr:.4f}
Encrypted ↔ Decrypted: {enc_dec_corr:.4f}

Status: {'SUCCESS' if orig_dec_corr > 0.95 else 'ISSUES DETECTED'}
        """
        messagebox.showinfo("Analysis Results", summary)

def main():
    root = tk.Tk()
    app = ImageHistogramAnalyzer(root)
    root.mainloop()

if __name__ == "__main__":
    main()