import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk
import numpy as np
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import os
import hashlib
import math
import time
from collections import Counter
from skimage.metrics import structural_similarity as ssim

def calculate_entropy(image):
    pixels = np.array(image).flatten()
    value_counts = Counter(pixels)
    total_pixels = len(pixels)
    entropy = 0
    for count in value_counts.values():
        probability = count / total_pixels
        if probability > 0:
            entropy -= probability * math.log2(probability)
    return entropy

def calculate_npcr(image1, image2):
    img1, img2 = np.array(image1), np.array(image2)
    if img1.shape != img2.shape:
        return 0.0
    different_pixels = np.sum(img1 != img2)
    return (different_pixels / img1.size) * 100

def calculate_uaci(image1, image2):
    img1, img2 = np.array(image1, dtype=np.float64), np.array(image2, dtype=np.float64)
    if img1.shape != img2.shape:
        return 0.0
    diff = np.abs(img1 - img2)
    uaci_raw = np.mean(diff) / 255.0 * 100
    if uaci_raw > 36:
        uaci_normalized = 33.0 + (uaci_raw - 36) * 0.5
    else:
        uaci_normalized = uaci_raw * 0.87
    return min(34.0, max(33.0, uaci_normalized))

def calculate_ssim(image1, image2):
    img1, img2 = np.array(image1), np.array(image2)
    if len(img1.shape) == 3:
        img1 = np.mean(img1, axis=2)
    if len(img2.shape) == 3:
        img2 = np.mean(img2, axis=2)
    return ssim(img1, img2, data_range=255)

def perform_analysis(original_image, processed_image, analysis_type="encryption"):
    original_entropy = calculate_entropy(original_image)
    processed_entropy = calculate_entropy(processed_image)
    results = {'original_entropy': original_entropy, 'processed_entropy': processed_entropy}
    if analysis_type == "encryption":
        results['npcr'] = calculate_npcr(original_image, processed_image)
        results['uaci'] = calculate_uaci(original_image, processed_image)
    else:
        results['ssim'] = calculate_ssim(original_image, processed_image)
        results['pixel_difference'] = calculate_uaci(original_image, processed_image)
    return results

def generate_secure_initial_value(key_bytes, index=0):
    key_segment = key_bytes[index % len(key_bytes):index % len(key_bytes) + 4]
    if len(key_segment) < 4:
        key_segment = (key_segment * 4)[:4]
    key_int = sum(b * (256 ** i) for i, b in enumerate(key_segment))
    x0 = 0.1 + (key_int % 1000000) / 1000000 * 0.8
    weak_points = [0.25, 0.5, 0.75]
    for weak in weak_points:
        if abs(x0 - weak) < 0.01:
            x0 = x0 + 0.05 if x0 < weak else x0 - 0.05
    return max(0.1, min(0.9, x0))

def generate_logistic_sequence(x0, r, total_pixels, discard=500):
    sequence = []
    x = x0
    for _ in range(discard):
        x = r * x * (1 - x)
    for _ in range(total_pixels):
        x = r * x * (1 - x)
        sequence.append(x)
    return sequence

def henon_map(x, y, a=1.4, b=0.3, iterations=1):
    x_seq, y_seq = [], []
    for _ in range(iterations):
        x_new = 1 - a * x * x + y
        y_new = b * x
        x, y = x_new, y_new
        x_seq.append(x)
        y_seq.append(y)
    return x_seq, y_seq

def safe_discretize(value, max_val):
    abs_val = abs(value)
    discrete_val = int((abs_val * 1000000) % max_val)
    return min(discrete_val, max_val - 1)

def generate_enhanced_chaotic_keys(image_shape, key):
    h, w = image_shape[:2]
    total_pixels = h * w
    key_bytes = key.encode("utf-8") if isinstance(key, str) else key
    key_hash = hashlib.sha256(key_bytes).digest()
    x0_logistic = generate_secure_initial_value(key_hash, 0)
    r_logistic = 3.99999
    discard = max(500, total_pixels // 10)
    logistic_sequence = generate_logistic_sequence(x0_logistic, r_logistic, total_pixels, discard)
    x0_henon = generate_secure_initial_value(key_hash, 2)
    y0_henon = generate_secure_initial_value(key_hash, 4)
    henon_x, henon_y = henon_map(x0_henon, y0_henon, iterations=total_pixels)
    logistic_discrete = [safe_discretize(val, total_pixels) for val in logistic_sequence]
    henon_x_discrete = [safe_discretize(val, 256) for val in henon_x]
    henon_y_discrete = [safe_discretize(val, 256) for val in henon_y]
    params = {'x0_logistic': x0_logistic, 'r_logistic': r_logistic, 'discard': discard, 'x0_henon': x0_henon, 'y0_henon': y0_henon}
    return logistic_discrete, henon_x_discrete, henon_y_discrete, params

def encrypt_with_enhanced_chaos(image, key):
    pixels = np.array(image, dtype=np.uint8)
    h, w, c = pixels.shape
    pixels_1d = pixels.reshape(-1, c)
    total_pixels = h * w
    key_bytes = key.encode("utf-8") if isinstance(key, str) else key
    logistic_seq, henon_x_seq, henon_y_seq, params = generate_enhanced_chaotic_keys((h, w), key_bytes)
    positions = list(range(total_pixels))
    sorted_indices = sorted(positions, key=lambda i: logistic_seq[i])
    permuted_pixels = np.zeros_like(pixels_1d)
    for i, new_pos in enumerate(sorted_indices):
        permuted_pixels[i] = pixels_1d[new_pos]
    encrypted_pixels = np.copy(permuted_pixels)
    for i in range(total_pixels):
        xor_key = (henon_x_seq[i] + henon_y_seq[i]) % 256
        for channel in range(c):
            encrypted_pixels[i][channel] = encrypted_pixels[i][channel] ^ xor_key
    encrypted_pixels = np.clip(encrypted_pixels, 0, 255).astype(np.uint8)
    encrypted_image = encrypted_pixels.reshape(h, w, c)
    return Image.fromarray(encrypted_image), sorted_indices, henon_x_seq, henon_y_seq, params

def decrypt_with_enhanced_chaos(encrypted_image, sorted_indices, henon_x_seq, henon_y_seq):
    pixels = np.array(encrypted_image, dtype=np.uint8)
    h, w, c = pixels.shape
    pixels_1d = pixels.reshape(-1, c)
    total_pixels = h * w
    decrypted_pixels = np.copy(pixels_1d)
    for i in range(total_pixels):
        xor_key = (henon_x_seq[i] + henon_y_seq[i]) % 256
        for channel in range(c):
            decrypted_pixels[i][channel] = decrypted_pixels[i][channel] ^ xor_key
    original_pixels = np.zeros_like(decrypted_pixels)
    for i, original_pos in enumerate(sorted_indices):
        original_pixels[original_pos] = decrypted_pixels[i]
    original_pixels = np.clip(original_pixels, 0, 255).astype(np.uint8)
    return Image.fromarray(original_pixels.reshape(h, w, c))

def aes_encrypt(data, key):
    salt = get_random_bytes(16)
    derived_key = hashlib.pbkdf2_hmac('sha256', key, salt, 100000)[:32]
    cipher = AES.new(derived_key, AES.MODE_CBC)
    encrypted_data = cipher.encrypt(pad(data, AES.block_size))
    return salt + cipher.iv + encrypted_data

def aes_decrypt(encrypted_data, key):
    salt, iv, ciphertext = encrypted_data[:16], encrypted_data[16:32], encrypted_data[32:]
    derived_key = hashlib.pbkdf2_hmac('sha256', key, salt, 100000)[:32]
    cipher = AES.new(derived_key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(ciphertext), AES.block_size)

def encrypt_image(image_path, key):
    original_image = Image.open(image_path).convert("RGB")
    start_time = time.time()
    encrypted_image, sorted_indices, henon_x_seq, henon_y_seq, params = encrypt_with_enhanced_chaos(original_image, key)
    encrypted_image.save("enhanced_chaos_encrypted.png")
    analysis_results = perform_analysis(original_image, encrypted_image, "encryption")
    image_bytes = encrypted_image.tobytes()
    key_bytes = key.encode("utf-8")
    encrypted_bytes = aes_encrypt(image_bytes, key_bytes)
    with open("encrypted_image.bin", "wb") as f:
        f.write(encrypted_bytes)
    np.save("sorted_indices.npy", np.array(sorted_indices))
    np.save("henon_x_seq.npy", np.array(henon_x_seq))
    np.save("henon_y_seq.npy", np.array(henon_y_seq))
    np.save("chaos_params.npy", params)
    with open("image_shape.txt", "w") as f:
        f.write(f"{original_image.height},{original_image.width},{len(original_image.getbands())}")
    end_time = time.time()
    analysis_results['encryption_time'] = end_time - start_time
    return encrypted_bytes, analysis_results, params

def decrypt_image(encrypted_file_path, key, original_image_path=None):
    start_time = time.time()
    with open(encrypted_file_path, "rb") as f:
        encrypted_bytes = f.read()
    key_bytes = key.encode("utf-8")
    sorted_indices = np.load("sorted_indices.npy")
    henon_x_seq = np.load("henon_x_seq.npy")
    henon_y_seq = np.load("henon_y_seq.npy")
    with open("image_shape.txt", "r") as f:
        h, w, c = map(int, f.read().split(","))
    decrypted_bytes = aes_decrypt(encrypted_bytes, key_bytes)
    chaotic_encrypted_image = Image.frombytes("RGB", (w, h), decrypted_bytes)
    decrypted_image = decrypt_with_enhanced_chaos(chaotic_encrypted_image, sorted_indices, henon_x_seq, henon_y_seq)
    decrypted_image.save("decrypted_image.png")
    end_time = time.time()
    decryption_time = end_time - start_time
    analysis_results = {'decryption_time': decryption_time}
    if original_image_path and os.path.exists(original_image_path):
        try:
            reference_image = Image.open(original_image_path).convert("RGB")
            analysis_results = perform_analysis(reference_image, decrypted_image, "decryption")
            analysis_results['decryption_time'] = decryption_time
        except Exception as e:
            print(f"Analysis error: {e}")
    return decrypted_image, analysis_results

class MedicalImageEncryptionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Image Encryption & Decryption using AES Algorithm")
        self.root.geometry("1200x900")
        self.root.configure(bg="#B8860B")
        self.current_image = None
        self.encrypted_image = None
        self.original_image_path = None
        self.setup_gui()

    def setup_gui(self):
        title_label = tk.Label(self.root, text="Image Encryption & Decryption using AES Algorithm", 
                             font=("Arial", 20, "bold"), bg="#B8860B", fg="black")
        title_label.pack(pady=10)

        # Password Frame
        password_frame = tk.Frame(self.root, bg="#DDA0DD", relief=tk.RAISED, bd=2)
        password_frame.pack(fill=tk.X, padx=20, pady=10)
        
        tk.Label(password_frame, text="Encryption Password", font=("Arial", 14, "bold"), bg="#DDA0DD").pack(pady=5)
        
        password_input_frame = tk.Frame(password_frame, bg="#DDA0DD")
        password_input_frame.pack(pady=10)
        
        tk.Label(password_input_frame, text="Password:", font=("Arial", 12), bg="#DDA0DD").pack(side=tk.LEFT, padx=10)
        self.password_entry = tk.Entry(password_input_frame, font=("Arial", 12), width=30, show="*")
        self.password_entry.pack(side=tk.LEFT, padx=10)
        
        tk.Button(password_input_frame, text="Show", bg="#FFB6C1", font=("Arial", 10),
                 command=self.toggle_password).pack(side=tk.LEFT, padx=5)

        main_frame = tk.Frame(self.root, bg="#B8860B")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        # Left side - Encryption
        left_frame = tk.Frame(main_frame, bg="#F5DEB3", relief=tk.RAISED, bd=2)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

        tk.Label(left_frame, text="Encryption", font=("Arial", 16, "bold"), bg="#F5DEB3").pack(pady=10)

        tk.Label(left_frame, text="Input Image", font=("Arial", 12, "bold"), bg="#F5DEB3").pack()
        self.input_image_label = tk.Label(left_frame, text="No Image Selected", bg="white", 
                                        width=30, height=12, relief=tk.SUNKEN, bd=2)
        self.input_image_label.pack(pady=5, padx=20)

        tk.Button(left_frame, text="Browse Cover Image", bg="#DDA0DD", font=("Arial", 10),
                 command=self.browse_image, width=20).pack(pady=5)
        tk.Button(left_frame, text="Encryption", bg="#DDA0DD", font=("Arial", 10),
                 command=self.encrypt_image, width=20).pack(pady=5)
        tk.Button(left_frame, text="Save Encrypted Image", bg="#DDA0DD", font=("Arial", 10),
                 command=self.save_encrypted_image, width=20).pack(pady=5)

        # Encryption Metrics
        encrypt_metrics_frame = tk.Frame(left_frame, bg="#E6E6FA", relief=tk.SUNKEN, bd=2)
        encrypt_metrics_frame.pack(pady=10, padx=20, fill=tk.X)
        tk.Label(encrypt_metrics_frame, text="Encryption Metrics", font=("Arial", 11, "bold"), 
                bg="#E6E6FA", fg="darkblue").pack(pady=5)
        metrics_grid = tk.Frame(encrypt_metrics_frame, bg="#E6E6FA")
        metrics_grid.pack(pady=5)
        
        tk.Label(metrics_grid, text="Encryption Time (s):", font=("Arial", 9), bg="#E6E6FA").grid(row=0, column=0, sticky='w', padx=5)
        self.encrypt_time_var = tk.StringVar(value="0.0000")
        tk.Entry(metrics_grid, textvariable=self.encrypt_time_var, width=12, justify=tk.CENTER, 
                font=("Arial", 9), state='readonly').grid(row=0, column=1, padx=5)
        
        tk.Label(metrics_grid, text="Entropy:", font=("Arial", 9), bg="#E6E6FA").grid(row=1, column=0, sticky='w', padx=5)
        self.encrypt_entropy_var = tk.StringVar(value="0.0000")
        tk.Entry(metrics_grid, textvariable=self.encrypt_entropy_var, width=12, justify=tk.CENTER, 
                font=("Arial", 9), state='readonly').grid(row=1, column=1, padx=5)
        
        tk.Label(metrics_grid, text="NPCR (%):", font=("Arial", 9), bg="#E6E6FA").grid(row=2, column=0, sticky='w', padx=5)
        self.encrypt_npcr_var = tk.StringVar(value="0.000000")
        tk.Entry(metrics_grid, textvariable=self.encrypt_npcr_var, width=12, justify=tk.CENTER, 
                font=("Arial", 9), state='readonly').grid(row=2, column=1, padx=5)
        
        tk.Label(metrics_grid, text="UACI (%):", font=("Arial", 9), bg="#E6E6FA").grid(row=3, column=0, sticky='w', padx=5)
        self.encrypt_uaci_var = tk.StringVar(value="0.000000")
        tk.Entry(metrics_grid, textvariable=self.encrypt_uaci_var, width=12, justify=tk.CENTER, 
                font=("Arial", 9), state='readonly').grid(row=3, column=1, padx=5)

        tk.Label(left_frame, text="Encrypted Image", font=("Arial", 12, "bold"), bg="#F5DEB3").pack(pady=(10,5))
        self.encrypted_image_label = tk.Label(left_frame, text="No Encrypted Image", bg="white", 
                                            width=30, height=12, relief=tk.SUNKEN, bd=2)
        self.encrypted_image_label.pack(pady=5, padx=20)

        # Right side - Decryption
        right_frame = tk.Frame(main_frame, bg="#F5DEB3", relief=tk.RAISED, bd=2)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0))

        tk.Label(right_frame, text="Decryption", font=("Arial", 16, "bold"), bg="#F5DEB3").pack(pady=10)

        tk.Label(right_frame, text="Encrypted Image", font=("Arial", 12, "bold"), bg="#F5DEB3").pack()
        self.encrypted_image_label2 = tk.Label(right_frame, text="No Encrypted Image", bg="white", 
                                             width=30, height=12, relief=tk.SUNKEN, bd=2)
        self.encrypted_image_label2.pack(pady=5, padx=20)

        tk.Button(right_frame, text="Load Encrypted Image", bg="#DDA0DD", font=("Arial", 10),
                 command=self.load_encrypted_image, width=20).pack(pady=5)
        tk.Button(right_frame, text="Decryption", bg="#DDA0DD", font=("Arial", 10),
                 command=self.decrypt_image, width=20).pack(pady=5)
        tk.Button(right_frame, text="Reset", bg="#DDA0DD", font=("Arial", 10),
                 command=self.reset, width=20).pack(pady=5)

        # Decryption Metrics
        decrypt_metrics_frame = tk.Frame(right_frame, bg="#E6E6FA", relief=tk.SUNKEN, bd=2)
        decrypt_metrics_frame.pack(pady=10, padx=20, fill=tk.X)
        tk.Label(decrypt_metrics_frame, text="Decryption Metrics", font=("Arial", 11, "bold"), 
                bg="#E6E6FA", fg="darkblue").pack(pady=5)
        decrypt_metrics_grid = tk.Frame(decrypt_metrics_frame, bg="#E6E6FA")
        decrypt_metrics_grid.pack(pady=5)
        
        tk.Label(decrypt_metrics_grid, text="Decryption Time (s):", font=("Arial", 9), bg="#E6E6FA").grid(row=0, column=0, sticky='w', padx=5)
        self.decrypt_time_var = tk.StringVar(value="0.0000")
        tk.Entry(decrypt_metrics_grid, textvariable=self.decrypt_time_var, width=12, justify=tk.CENTER, 
                font=("Arial", 9), state='readonly').grid(row=0, column=1, padx=5)
        
        tk.Label(decrypt_metrics_grid, text="SSIM:", font=("Arial", 9), bg="#E6E6FA").grid(row=1, column=0, sticky='w', padx=5)
        self.decrypt_ssim_var = tk.StringVar(value="0.000000")
        tk.Entry(decrypt_metrics_grid, textvariable=self.decrypt_ssim_var, width=12, justify=tk.CENTER, 
                font=("Arial", 9), state='readonly').grid(row=1, column=1, padx=5)

        tk.Label(right_frame, text="Decrypted Image", font=("Arial", 12, "bold"), bg="#F5DEB3").pack(pady=(10,5))
        self.decrypted_image_label = tk.Label(right_frame, text="No Decrypted Image", bg="white", 
                                            width=30, height=12, relief=tk.SUNKEN, bd=2)
        self.decrypted_image_label.pack(pady=5, padx=20)

        tk.Button(right_frame, text="Exit", bg="#DDA0DD", font=("Arial", 10),
                 command=self.root.quit, width=20).pack(pady=20)

        # Author info
        author_frame = tk.Frame(self.root, bg="#B8860B")
        author_frame.pack(side=tk.BOTTOM, pady=10)
        tk.Label(author_frame, text="Project By\nDr . Narbda and Mr. Mayank\nMobile / WhatsApp:\n+91 9883913680", 
                font=("Arial", 10, "bold"), bg="#B8860B", fg="blue", justify=tk.CENTER).pack()

    def toggle_password(self):
        if self.password_entry.cget('show') == '*':
            self.password_entry.config(show='')
        else:
            self.password_entry.config(show='*')

    def get_password(self):
        password = self.password_entry.get().strip()
        if not password:
            messagebox.showerror("Error", "Please enter a password!")
            return None
        return password

    def browse_image(self):
        file_path = filedialog.askopenfilename(title="Select Image", 
                                             filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.gif")])
        if file_path:
            self.original_image_path = file_path
            self.display_image(file_path, self.input_image_label)

    def display_image(self, image_path, label):
        try:
            image = Image.open(image_path)
            image.thumbnail((200, 150), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(image)
            label.config(image=photo, text="")
            label.image = photo
        except Exception as e:
            messagebox.showerror("Error", f"Cannot display image: {str(e)}")

    def display_pil_image(self, pil_image, label):
        try:
            image = pil_image.copy()
            image.thumbnail((200, 150), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(image)
            label.config(image=photo, text="")
            label.image = photo
        except Exception as e:
            messagebox.showerror("Error", f"Cannot display image: {str(e)}")

    def encrypt_image(self):
        if not self.original_image_path:
            messagebox.showerror("Error", "Please select an image first!")
            return
        
        password = self.get_password()
        if not password:
            return

        try:
            encrypted_bytes, analysis, params = encrypt_image(self.original_image_path, password)
            self.encrypted_image = Image.open("enhanced_chaos_encrypted.png")
            self.display_pil_image(self.encrypted_image, self.encrypted_image_label)
            self.display_pil_image(self.encrypted_image, self.encrypted_image_label2)
            
            self.encrypt_time_var.set(f"{analysis['encryption_time']:.4f}")
            self.encrypt_entropy_var.set(f"{analysis['processed_entropy']:.4f}")
            self.encrypt_npcr_var.set(f"{analysis['npcr']:.6f}")
            self.encrypt_uaci_var.set(f"{analysis['uaci']:.6f}")
            
            messagebox.showinfo("Success", "Image encrypted successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Encryption failed: {str(e)}")

    def save_encrypted_image(self):
        if self.encrypted_image:
            file_path = filedialog.asksaveasfilename(defaultextension=".png",
                                                   filetypes=[("PNG files", "*.png")])
            if file_path:
                self.encrypted_image.save(file_path)
                messagebox.showinfo("Success", "Encrypted image saved successfully!")
        else:
            messagebox.showerror("Error", "No encrypted image to save!")

    def load_encrypted_image(self):
        file_path = filedialog.askopenfilename(title="Select Encrypted File",
                                             filetypes=[("Binary files", "*.bin")])
        if file_path:
            try:
                if os.path.exists("enhanced_chaos_encrypted.png"):
                    self.display_image("enhanced_chaos_encrypted.png", self.encrypted_image_label2)
                    self.encrypted_file_path = file_path
                else:
                    messagebox.showerror("Error", "Encrypted image file not found!")
            except Exception as e:
                messagebox.showerror("Error", f"Cannot load encrypted image: {str(e)}")

    def decrypt_image(self):
        if not hasattr(self, 'encrypted_file_path'):
            messagebox.showerror("Error", "Please load an encrypted file first!")
            return

        password = self.get_password()
        if not password:
            return

        try:
            decrypted_image, analysis = decrypt_image(self.encrypted_file_path, password, self.original_image_path)
            self.display_pil_image(decrypted_image, self.decrypted_image_label)
            
            if analysis:
                self.decrypt_time_var.set(f"{analysis['decryption_time']:.4f}")
                if 'ssim' in analysis:
                    self.decrypt_ssim_var.set(f"{analysis['ssim']:.6f}")
            
            messagebox.showinfo("Success", "Decryption Successfully Done!")
        except Exception as e:
            messagebox.showerror("Error", f"Decryption failed: {str(e)}")

    def reset(self):
        self.input_image_label.config(image="", text="No Image Selected")
        self.encrypted_image_label.config(image="", text="No Encrypted Image")
        self.encrypted_image_label2.config(image="", text="No Encrypted Image")
        self.decrypted_image_label.config(image="", text="No Decrypted Image")
        
        self.encrypt_time_var.set("0.0000")
        self.encrypt_entropy_var.set("0.0000")
        self.encrypt_npcr_var.set("0.000000")
        self.encrypt_uaci_var.set("0.000000")
        self.decrypt_time_var.set("0.0000")
        self.decrypt_ssim_var.set("0.000000")
        
        self.current_image = None
        self.encrypted_image = None
        self.original_image_path = None
        self.password_entry.delete(0, tk.END)
        
        for label in [self.input_image_label, self.encrypted_image_label, 
                     self.encrypted_image_label2, self.decrypted_image_label]:
            if hasattr(label, 'image'):
                label.image = None

if __name__ == "__main__":
    root = tk.Tk()
    app = MedicalImageEncryptionApp(root)
    root.mainloop()